// programmer: Cruz Macias
// description: Java program to print a message to the console
public class y
{
	public static void main(String[] args)
	{
		System.out.println("Hello from my Java Program CSC 815!");
	}
}// end main class
