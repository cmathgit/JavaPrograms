// programmer: Cruz Macias
// description: C program to print a message to the console
//header file for input/output
#include <stdio.h>

int main() {
    //use printf to output to console
    printf("Hello from my C Program CSC 815!\n");
	
    return 0;
}